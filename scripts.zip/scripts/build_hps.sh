#!/bin/bash

# Script to build the HPS software for the monociclo project

# Navigate to the HPS source directory
cd ../software/hps/src

# Compile the HPS software
gcc -o main main.c

# Check if the compilation was successful
if [ $? -eq 0 ]; then
    echo "HPS software built successfully."
else
    echo "HPS software build failed."
    exit 1
fi

# Return to the original directory
cd ../../..