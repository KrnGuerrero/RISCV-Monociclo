#!/bin/bash

# Script to program the FPGA on the DE1-SoC with the compiled design

# Set the path to the Quartus tools
QUARTUS_PATH="/path/to/quartus"

# Set the project directory
PROJECT_DIR="$(dirname "$(realpath "$0")/../hardware/fpga/quartus")"

# Change to the project directory
cd "$PROJECT_DIR" || exit

# Compile the design
$QUARTUS_PATH/quartus_sh compile project.qpf

# Program the FPGA
$QUARTUS_PATH/quartus_pgm -m JTAG -o "p;project.sof"