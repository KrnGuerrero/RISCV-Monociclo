#!/bin/bash

# This script runs the simulation tests for the FPGA design.

# Set the simulation tool and options
SIM_TOOL="vcs"
SIM_OPTIONS="-full64 -debug_all"

# Define the source files and testbench
SRC_FILES="../hardware/fpga/src/top.sv ../hardware/fpga/src/alu.sv ../hardware/fpga/src/register_file.sv ../hardware/fpga/src/switch_reader.sv ../hardware/fpga/src/seven_seg_driver.sv"
TB_FILES="../hardware/tb/tb_top.sv ../hardware/tb/tb_alu.sv"

# Compile the design and testbench
$SIM_TOOL $SIM_OPTIONS $SRC_FILES $TB_FILES -o simulation_executable

# Run the simulation
./simulation_executable

# Check the simulation results
if [ $? -eq 0 ]; then
    echo "Simulation completed successfully."
else
    echo "Simulation failed."
fi