# Monociclo DE1-SoC Project Specification

## Overview
The Monociclo project is designed to implement a simple arithmetic unit using an FPGA DE1-SoC. The system allows users to input two numbers and select an operation (addition, subtraction, AND, OR) using physical switches. The results are displayed on a seven-segment display.

## Hardware Components
- **FPGA**: The core of the project, where the logic is implemented.
- **Switches**: Used for inputting two numbers and selecting the operation.
- **Seven-Segment Display**: Displays the result of the arithmetic operation.

## Functional Requirements
1. **Input Handling**:
   - Four switches for the first number (0-15).
   - Four switches for the second number (0-15).
   - Two switches for operation selection:
     - Switch 0: Addition
     - Switch 1: Subtraction
     - Switch 2: AND
     - Switch 3: OR

2. **ALU Operations**:
   - The ALU should perform the following operations based on the selected instruction:
     - Addition
     - Subtraction
     - Bitwise AND
     - Bitwise OR

3. **Output Display**:
   - The result of the operation should be displayed on a seven-segment display.

## Design Files
- **top.sv**: Top-level module that connects the ALU, register file, and switch reader.
- **alu.sv**: Implements the ALU functionality.
- **register_file.sv**: Stores input numbers and the result.
- **switch_reader.sv**: Reads switch states and converts them to binary and control signals.
- **seven_seg_driver.sv**: Drives the seven-segment display to show results.

## Constraints
- **Pin Assignments**: Defined in `de1_soc_pin_assignments.qsf` to map physical pins to signals.

## Testing
- **Testbenches**: 
  - `tb_top.sv`: Tests the top-level module.
  - `tb_alu.sv`: Tests the ALU functionality with various inputs.

## Software Components
- **HPS**: Contains the main program for additional processing or interfacing with the FPGA.
- **Makefile**: Automates the build process for the HPS software.

## Documentation
- **Interface Documentation**: Detailed in `interface.md`, explaining signal definitions and protocols between components.

## Scripts
- **Programming and Build Scripts**: 
  - `program_fpga.sh`: Automates FPGA programming.
  - `build_hps.sh`: Automates HPS software build process.

## Conclusion
This project aims to provide a simple yet effective demonstration of FPGA capabilities in performing arithmetic operations based on user input through physical switches, with results displayed visually.