# Bare-metal Software for Monociclo DE1-SoC

This README file provides documentation for the bare-metal software environment used in the Monociclo project on the DE1-SoC FPGA platform.

## Overview

The bare-metal software is designed to interface with the FPGA components of the Monociclo project. It allows for direct control and interaction with the hardware without the overhead of an operating system.

## Setup Instructions

1. **Prerequisites**: Ensure you have the necessary tools installed:
   - A compatible compiler for the HPS (Hard Processor System).
   - The Quartus software for FPGA programming.

2. **Directory Structure**: The bare-metal software is located in the `software/baremetal` directory. The main source file is `main.c`.

3. **Building the Software**:
   - Navigate to the `software/hps` directory.
   - Run the `Makefile` to compile the HPS software:
     ```
     make
     ```

4. **Programming the FPGA**:
   - Use the provided script in the `scripts` directory to program the FPGA:
     ```
     ./program_fpga.sh
     ```

5. **Running the Software**:
   - After programming the FPGA, load the compiled HPS software onto the HPS and execute it.

## Usage

The bare-metal software allows you to perform operations such as addition, subtraction, AND, and OR using the FPGA's ALU. The input numbers are provided through the switches, and the results are displayed on the seven-segment display.

## Contributing

Contributions to the bare-metal software are welcome. Please follow the project's guidelines for contributing.

## License

This project is licensed under the terms specified in the LICENSE file.