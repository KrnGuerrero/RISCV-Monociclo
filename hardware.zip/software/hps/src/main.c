#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

// Function prototypes
void perform_operation(uint8_t num1, uint8_t num2, uint8_t operation);

int main() {
    // Variables to hold the input numbers and operation
    uint8_t num1 = 0;
    uint8_t num2 = 0;
    uint8_t operation = 0;

    // Simulate reading from switches (for demonstration purposes)
    // In a real application, this would interface with the FPGA
    printf("Enter first number (0-15): ");
    scanf("%hhu", &num1);
    printf("Enter second number (0-15): ");
    scanf("%hhu", &num2);
    printf("Enter operation (0: Add, 1: Subtract, 2: AND, 3: OR): ");
    scanf("%hhu", &operation);

    // Perform the operation
    perform_operation(num1, num2, operation);

    return 0;
}

void perform_operation(uint8_t num1, uint8_t num2, uint8_t operation) {
    uint8_t result;

    switch (operation) {
        case 0: // Addition
            result = num1 + num2;
            printf("Result: %hhu\n", result);
            break;
        case 1: // Subtraction
            result = num1 - num2;
            printf("Result: %hhu\n", result);
            break;
        case 2: // AND
            result = num1 & num2;
            printf("Result: %hhu\n", result);
            break;
        case 3: // OR
            result = num1 | num2;
            printf("Result: %hhu\n", result);
            break;
        default:
            printf("Invalid operation\n");
            break;
    }
}