# Interface Documentation for Monociclo DE1-SoC Project

## Overview
This document outlines the interfaces between the various components of the Monociclo DE1-SoC project. It includes signal definitions and protocols used for communication between the FPGA modules and the external switches.

## Signal Definitions

### Switch Inputs
- **Switches for First Number (SW0 - SW3)**: 
  - These 4 switches are used to input the first number.
  - Signal Name: `first_number`
  - Bit Width: 4 bits (SW0 is the least significant bit)

- **Switches for Second Number (SW4 - SW7)**: 
  - These 4 switches are used to input the second number.
  - Signal Name: `second_number`
  - Bit Width: 4 bits (SW4 is the least significant bit)

### Operation Control
- **Operation Switches (SW8 - SW9)**: 
  - These 2 switches are used to select the operation to be performed by the ALU.
  - Signal Name: `operation`
  - Bit Width: 2 bits
    - `00`: Addition
    - `01`: Subtraction
    - `10`: AND
    - `11`: OR

### Output
- **ALU Result**: 
  - The result of the ALU operation is output to a seven-segment display.
  - Signal Name: `alu_result`
  - Bit Width: 4 bits

## Component Interfaces

### ALU
- **Inputs**:
  - `first_number`: 4 bits from the switch reader.
  - `second_number`: 4 bits from the switch reader.
  - `operation`: 2 bits from the operation control switches.
  
- **Output**:
  - `alu_result`: 4 bits to the seven-segment driver.

### Register File
- **Inputs**:
  - `first_number`: 4 bits from the switch reader.
  - `second_number`: 4 bits from the switch reader.
  
- **Outputs**:
  - `alu_result`: 4 bits to the ALU.

### Switch Reader
- **Inputs**:
  - Switches SW0 - SW9 for number and operation input.
  
- **Outputs**:
  - `first_number`: 4 bits to the register file.
  - `second_number`: 4 bits to the register file.
  - `operation`: 2 bits to the ALU.

### Seven-Segment Driver
- **Inputs**:
  - `alu_result`: 4 bits from the ALU.
  
- **Outputs**:
  - Signals to drive the seven-segment display for visual output.

## Conclusion
This interface documentation provides a clear understanding of how the different components of the Monociclo DE1-SoC project interact with each other. Proper adherence to these definitions will ensure seamless communication and functionality within the project.